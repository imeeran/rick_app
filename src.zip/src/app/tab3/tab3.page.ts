import { Component, OnInit, OnDestroy, ViewChild, ElementRef, AfterViewInit, NgZone } from '@angular/core';
import { CommonModule } from '@angular/common';
import { 
  IonContent, 
  IonButton,
  IonIcon,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardTitle,
  IonSpinner
} from '@ionic/angular/standalone';
import { ViewDidEnter } from '@ionic/angular';
import { addIcons } from 'ionicons';
import { 
  locationOutline, 
  flagOutline, 
  personOutline,
  checkmarkCircleOutline,
  closeCircleOutline
} from 'ionicons/icons';
import { Geolocation } from '@capacitor/geolocation';
import { BookingsService, Booking } from '../services/bookings.service';
import * as L from 'leaflet';
import { interval, Subscription } from 'rxjs';

// Fix for default marker icon issue in Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss'],
  imports: [
    CommonModule,
    IonContent,
    IonButton,
    IonIcon,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardTitle,
    IonSpinner
  ],
})
export class Tab3Page implements OnInit, AfterViewInit, OnDestroy, ViewDidEnter {
  @ViewChild('mapContainer', { static: false }) mapContainer!: ElementRef;

  map!: L.Map;
  currentLocation: { lat: number; lng: number } | null = null;
  isOnline = false;
  upcomingRide: Booking | null = null;
  isLoading = true;
  isMapReady = false;

  // Route animation
  private routePolyline: L.Polyline | null = null;
  private vehicleMarker: L.Marker | null = null;
  private animationInterval: Subscription | null = null;
  private routeCoordinates: L.LatLng[] = [];
  private currentRouteIndex = 0;
  private isAnimating = false;
  private watchId: string | null = null;
  private resizeListener?: () => void;
  private mapInitAttempts = 0;
  private readonly MAX_MAP_INIT_ATTEMPTS = 10;

  constructor(
    private bookingsService: BookingsService,
    private ngZone: NgZone
  ) {
    addIcons({
      'location-outline': locationOutline,
      'flag-outline': flagOutline,
      'person-outline': personOutline,
      'checkmark-circle-outline': checkmarkCircleOutline,
      'close-circle-outline': closeCircleOutline
    });
  }

  ngOnInit() {
    this.loadUpcomingRide();
  }

  ngAfterViewInit() {
    // Don't initialize map here - wait for ionViewDidEnter
  }

  ionViewDidEnter() {
    // Initialize map when view enters (container should have dimensions by now)
    if (!this.map) {
      this.mapInitAttempts = 0;
      // Wait a bit longer to ensure DOM is fully rendered
      setTimeout(() => {
        // Force container to have dimensions
        if (this.mapContainer?.nativeElement) {
          const container = this.mapContainer.nativeElement;
          const parent = container.parentElement;
          if (parent) {
            const parentRect = parent.getBoundingClientRect();
            if (parentRect.height > 0) {
              container.style.height = `${parentRect.height}px`;
            }
          }
        }
        this.initMap();
      }, 300);
    } else {
      // Resize map if it already exists
      setTimeout(() => {
        if (this.map) {
          this.map.invalidateSize();
        }
      }, 100);
    }
  }

  ngOnDestroy() {
    if (this.animationInterval) {
      this.animationInterval.unsubscribe();
    }
    if (this.watchId) {
      Geolocation.clearWatch({ id: this.watchId });
    }
    if (this.resizeListener) {
      window.removeEventListener('resize', this.resizeListener);
      window.removeEventListener('orientationchange', this.resizeListener);
    }
    if (this.map) {
      this.map.remove();
    }
  }

  async initMap() {
    // Prevent infinite retry loops
    if (this.mapInitAttempts >= this.MAX_MAP_INIT_ATTEMPTS) {
      console.error('Max map initialization attempts reached');
      this.isLoading = false;
      return;
    }

    this.mapInitAttempts++;

    try {
      // Check if ViewChild is available
      if (!this.mapContainer || !this.mapContainer.nativeElement) {
        console.warn(`Map container element not found (attempt ${this.mapInitAttempts}), retrying...`);
        requestAnimationFrame(() => {
          setTimeout(() => this.initMap(), 100);
        });
        return;
      }

      // Ensure container has dimensions first
      const container = this.mapContainer.nativeElement;
      
      // Force layout recalculation
      container.style.display = 'block';
      container.style.width = '100%';
      container.style.height = '100%';
      
      // Get dimensions using multiple methods
      const rect = container.getBoundingClientRect();
      const width = rect.width || container.offsetWidth || container.clientWidth || window.innerWidth;
      const height = rect.height || container.offsetHeight || container.clientHeight || window.innerHeight;
      
      if (!width || !height || width === 0 || height === 0) {
        // If still no dimensions, use viewport dimensions as fallback
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        
        if (viewportWidth > 0 && viewportHeight > 0) {
          console.warn(`Using viewport dimensions as fallback: ${viewportWidth}x${viewportHeight}`);
          container.style.width = `${viewportWidth}px`;
          container.style.height = `${viewportHeight}px`;
        } else {
          console.warn(`Map container has no dimensions (${width}x${height}, attempt ${this.mapInitAttempts}), retrying...`);
          requestAnimationFrame(() => {
            setTimeout(() => this.initMap(), 200);
          });
          return;
        }
      }

      // Get current location
      const position = await Geolocation.getCurrentPosition({ enableHighAccuracy: true });
      this.currentLocation = {
        lat: position.coords.latitude,
        lng: position.coords.longitude
      };

      // Ensure currentLocation is set
      if (!this.currentLocation) {
        console.error('Current location is not available');
        return;
      }

      // Initialize map
      this.map = L.map(this.mapContainer.nativeElement, {
        zoomControl: true,
        attributionControl: true,
        preferCanvas: false
      }).setView([this.currentLocation.lat, this.currentLocation.lng], 15);

      // Add tile layer
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19,
        tileSize: 256,
        zoomOffset: 0
      }).addTo(this.map);

      // Add current location marker
      L.marker([this.currentLocation.lat, this.currentLocation.lng], {
        icon: L.icon({
          iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-blue.png',
          iconSize: [25, 41],
          iconAnchor: [12, 41],
          popupAnchor: [1, -34],
        })
      }).addTo(this.map).bindPopup('Your Location');

      // Invalidate size to ensure map renders correctly
      setTimeout(() => {
        if (this.map && this.currentLocation) {
          this.map.invalidateSize();
          this.map.setView([this.currentLocation.lat, this.currentLocation.lng], 15);
        }
      }, 100);

      // Add resize listener for orientation changes
      this.resizeListener = () => {
        if (this.map) {
          setTimeout(() => {
            this.map.invalidateSize();
          }, 100);
        }
      };
      window.addEventListener('resize', this.resizeListener);
      window.addEventListener('orientationchange', this.resizeListener);

      this.isMapReady = true;
      this.isLoading = false;

      // If online and has ride, show route
      if (this.isOnline && this.upcomingRide) {
        this.showRoute();
      }

      // Watch position if online
      if (this.isOnline) {
        this.watchPosition();
      }
    } catch (error) {
      console.error('Error initializing map:', error);
      
      // Ensure container has dimensions before fallback
      const container = this.mapContainer.nativeElement;
      if (!container || container.offsetWidth === 0 || container.offsetHeight === 0) {
        console.warn(`Map container has no dimensions in fallback (attempt ${this.mapInitAttempts}), retrying...`);
        requestAnimationFrame(() => {
          setTimeout(() => this.initMap(), 100);
        });
        return;
      }

      // Fallback to default location
      this.currentLocation = { lat: 40.7128, lng: -74.0060 }; // New York default

      if (!this.currentLocation) {
        console.error('Current location is not available');
        this.isLoading = false;
        return;
      }

      this.map = L.map(this.mapContainer.nativeElement, {
        zoomControl: true,
        attributionControl: true
      }).setView([this.currentLocation.lat, this.currentLocation.lng], 13);
      
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
      }).addTo(this.map);
      
      // Invalidate size for fallback map too
      setTimeout(() => {
        this.map.invalidateSize();
      }, 100);
      
      this.isMapReady = true;
      this.isLoading = false;
    }
  }

  async watchPosition() {
    if (!this.isOnline) return;

    // Clear existing watch if any
    if (this.watchId) {
      Geolocation.clearWatch({ id: this.watchId });
    }

    try {
      this.watchId = await Geolocation.watchPosition(
        { enableHighAccuracy: true, timeout: 10000 },
        (position, err) => {
          if (err) {
            console.error('Watch position error:', err);
            return;
          }
          if (position) {
            this.ngZone.run(() => {
              this.currentLocation = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
              };
              // Update vehicle marker if animating
              if (this.isAnimating && this.vehicleMarker && this.currentLocation && this.map) {
                this.vehicleMarker.setLatLng([this.currentLocation.lat, this.currentLocation.lng]);
                this.map.setView([this.currentLocation.lat, this.currentLocation.lng], this.map.getZoom());
              }
            });
          }
        }
      );
    } catch (error) {
      console.error('Error watching position:', error);
    }
  }

  loadUpcomingRide() {
    this.bookingsService.getBookingsByStatus('upcoming').subscribe(bookings => {
      if (bookings && bookings.length > 0) {
        // Get the earliest upcoming ride
        this.upcomingRide = bookings[0];
        if (this.isMapReady && this.isOnline) {
          this.showRoute();
        }
      }
    });
  }

  toggleOnlineStatus() {
    this.isOnline = !this.isOnline;
    if (this.isOnline) {
      this.watchPosition();
      if (this.upcomingRide) {
        this.showRoute();
      }
    } else {
      // Stop watching position
      if (this.watchId) {
        Geolocation.clearWatch({ id: this.watchId });
        this.watchId = null;
      }
      this.stopAnimation();
      if (this.routePolyline) {
        this.map.removeLayer(this.routePolyline);
        this.routePolyline = null;
      }
      if (this.vehicleMarker) {
        this.map.removeLayer(this.vehicleMarker);
        this.vehicleMarker = null;
      }
    }
  }

  async showRoute() {
    if (!this.upcomingRide || !this.currentLocation || !this.map) return;

    // Generate route coordinates (simulated route from current location to pickup)
    // In a real app, you would use a routing service like OSRM or Google Directions API
    const pickupCoords = this.geocodeLocation(this.upcomingRide.pickupLocation);
    const dropoffCoords = this.geocodeLocation(this.upcomingRide.dropoffLocation);

    // Create route from current location to pickup, then to dropoff
    this.routeCoordinates = [
      L.latLng(this.currentLocation.lat, this.currentLocation.lng),
      ...this.generateRoutePoints(
        this.currentLocation,
        pickupCoords
      ),
      L.latLng(pickupCoords.lat, pickupCoords.lng),
      ...this.generateRoutePoints(
        pickupCoords,
        dropoffCoords
      ),
      L.latLng(dropoffCoords.lat, dropoffCoords.lng)
    ];

    // Draw route polyline
    if (this.routePolyline) {
      this.map.removeLayer(this.routePolyline);
    }

    this.routePolyline = L.polyline(this.routeCoordinates, {
      color: '#3880ff',
      weight: 5,
      opacity: 0.7
    }).addTo(this.map);

    // Add markers for pickup and dropoff
    L.marker([pickupCoords.lat, pickupCoords.lng], {
      icon: L.icon({
        iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-green.png',
        iconSize: [25, 41],
        iconAnchor: [12, 41],
      })
    }).addTo(this.map).bindPopup(`Pickup: ${this.upcomingRide.pickupLocation}`);

    L.marker([dropoffCoords.lat, dropoffCoords.lng], {
      icon: L.icon({
        iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
        iconSize: [25, 41],
        iconAnchor: [12, 41],
      })
    }).addTo(this.map).bindPopup(`Dropoff: ${this.upcomingRide.dropoffLocation}`);

    // Fit map to show entire route
    const bounds = L.latLngBounds(this.routeCoordinates);
    this.map.fitBounds(bounds, { padding: [50, 50] });

    // Start vehicle animation
    if (this.isOnline) {
      this.startVehicleAnimation();
    }
  }

  generateRoutePoints(start: { lat: number; lng: number }, end: { lat: number; lng: number }): L.LatLng[] {
    const points: L.LatLng[] = [];
    const steps = 10;
    for (let i = 1; i < steps; i++) {
      const ratio = i / steps;
      const lat = start.lat + (end.lat - start.lat) * ratio;
      const lng = start.lng + (end.lng - start.lng) * ratio;
      points.push(L.latLng(lat, lng));
    }
    return points;
  }

  startVehicleAnimation() {
    if (this.isAnimating || this.routeCoordinates.length === 0) return;

    this.stopAnimation();
    this.isAnimating = true;
    this.currentRouteIndex = 0;

    // Create vehicle marker with custom icon
    const vehicleIcon = L.divIcon({
      className: 'vehicle-marker',
      html: '<div class="vehicle-icon">🚗</div>',
      iconSize: [40, 40],
      iconAnchor: [20, 20]
    });

    this.vehicleMarker = L.marker(this.routeCoordinates[0], { icon: vehicleIcon }).addTo(this.map);

    // Animate along route
    this.animationInterval = interval(200).subscribe(() => {
      if (this.currentRouteIndex < this.routeCoordinates.length - 1) {
        this.currentRouteIndex++;
        const nextPoint = this.routeCoordinates[this.currentRouteIndex];
        if (this.vehicleMarker) {
          this.vehicleMarker.setLatLng(nextPoint);
          // Smoothly pan map to follow vehicle
          this.map.panTo(nextPoint, { animate: true, duration: 0.2 });
        }
      } else {
        // Reached destination, restart animation
        this.currentRouteIndex = 0;
      }
    });
  }

  stopAnimation() {
    if (this.animationInterval) {
      this.animationInterval.unsubscribe();
      this.animationInterval = null;
    }
    this.isAnimating = false;
  }

  geocodeLocation(locationName: string): { lat: number; lng: number } {
    // Simple geocoding simulation - in a real app, use a geocoding service
    // For demo purposes, generate coordinates near current location
    const baseLat = this.currentLocation?.lat || 40.7128;
    const baseLng = this.currentLocation?.lng || -74.0060;
    
    // Add some random offset based on location name hash
    const hash = locationName.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const latOffset = (hash % 100) / 1000;
    const lngOffset = ((hash * 7) % 100) / 1000;
    
    return {
      lat: baseLat + latOffset,
      lng: baseLng + lngOffset
    };
  }

  acceptRide() {
    if (this.upcomingRide) {
      console.log('Ride accepted:', this.upcomingRide.id);
      // In a real app, call API to accept ride
      // For now, just show route if online
      if (this.isOnline) {
        this.showRoute();
      }
    }
  }

  rejectRide() {
    if (this.upcomingRide) {
      console.log('Ride rejected:', this.upcomingRide.id);
      // In a real app, call API to reject ride
      this.upcomingRide = null;
      this.stopAnimation();
      if (this.routePolyline) {
        this.map.removeLayer(this.routePolyline);
        this.routePolyline = null;
      }
      if (this.vehicleMarker) {
        this.map.removeLayer(this.vehicleMarker);
        this.vehicleMarker = null;
      }
      // Load next ride
      this.loadUpcomingRide();
    }
  }

  formatDate(date: Date): string {
    return new Date(date).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    });
  }
}
