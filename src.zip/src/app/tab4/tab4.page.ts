import { Component, OnInit, OnDestroy, signal, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { 
  IonContent,
  IonSegment,
  IonSegmentButton,
  IonCard,
  IonCardContent,
  IonItem,
  IonLabel,
  IonSelect,
  IonSelectOption,
  IonIcon,
  IonAccordion,
  IonAccordionGroup
} from '@ionic/angular/standalone';
import { BookingsService, Booking } from '../services/bookings.service';
import { ThemeService } from '../services/theme.service';
import { Subscription } from 'rxjs';
import { addIcons } from 'ionicons';
import { locationOutline, flagOutline, personOutline, timeOutline, calendarOutline } from 'ionicons/icons';

interface MonthGroup {
  monthKey: string;
  monthName: string;
  year: number;
  bookings: Booking[];
}

@Component({
  selector: 'app-tab4',
  templateUrl: 'tab4.page.html',
  styleUrls: ['tab4.page.scss'],
  imports: [
    CommonModule,
    IonContent,
    IonSegment,
    IonSegmentButton,
    IonCard,
    IonCardContent,
    IonItem,
    IonLabel,
    IonSelect,
    IonSelectOption,
    IonIcon,
    IonAccordion,
    IonAccordionGroup
  ],
})
export class Tab4Page implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild('segmentElement', { read: ElementRef }) segmentElement!: ElementRef;
  
  selectedSegment = signal<'upcoming' | 'completed' | 'canceled'>('upcoming');
  selectedMonth = signal<string>('all');
  selectedYear = signal<string>('all');
  showAll = signal<boolean>(true);
  
  allBookings: Booking[] = [];
  filteredBookings = signal<Booking[]>([]);
  monthGroups = signal<MonthGroup[]>([]);
  
  months: { value: string; label: string }[] = [];
  years: { value: string; label: string }[] = [];
  currentMonthKey: string = '';
  private themeSubscription?: Subscription;

  constructor(
    private bookingsService: BookingsService,
    private themeService: ThemeService
  ) {
    addIcons({ locationOutline, flagOutline, personOutline, timeOutline, calendarOutline });
  }

  ngOnInit() {
    this.initializeMonths();
    this.initializeYears();
    this.loadBookings();
    this.setupThemeSubscription();
  }

  ngAfterViewInit() {
    this.updateSegmentColor();
  }

  ngOnDestroy() {
    if (this.themeSubscription) {
      this.themeSubscription.unsubscribe();
    }
  }

  private setupThemeSubscription() {
    this.themeSubscription = this.themeService.currentTheme$.subscribe(() => {
      setTimeout(() => {
        this.updateSegmentColor();
      }, 150);
    });
    // Set initial color
    setTimeout(() => {
      this.updateSegmentColor();
    }, 200);
  }

  private updateSegmentColor() {
    if (this.segmentElement?.nativeElement) {
      // Use the CSS variable that's already set by the theme service
      const primaryColor = getComputedStyle(document.documentElement)
        .getPropertyValue('--ion-color-primary')
        .trim();
      
      if (primaryColor) {
        const segmentEl = this.segmentElement.nativeElement;
        // Check if Android platform
        const isAndroid = document.body.classList.contains('md') || 
                         document.documentElement.classList.contains('md');
        
        if (isAndroid) {
          // For Android: use transparent indicator, background for selected
          segmentEl.style.setProperty('--indicator-color', 'transparent');
        } else {
          // For iOS: use primary color indicator
          segmentEl.style.setProperty('--indicator-color', primaryColor);
        }
        
        // Get text color for unselected buttons
        const textColor = getComputedStyle(document.documentElement)
          .getPropertyValue('--ion-text-color')
          .trim();
        
        // Update all segment buttons
        const segmentButtons = segmentEl.querySelectorAll('ion-segment-button');
        segmentButtons.forEach((button: Element) => {
          const htmlButton = button as HTMLElement;
          const isChecked = htmlButton.classList.contains('segment-button-checked');
          const label = htmlButton.querySelector('ion-label');
          
          if (isAndroid) {
            htmlButton.style.setProperty('--indicator-color', 'transparent');
            htmlButton.style.setProperty('--color-checked', '#ffffff');
            htmlButton.style.setProperty('--background-checked', primaryColor);
            htmlButton.style.setProperty('--ripple-color', primaryColor);
            
            // Set background and text color based on checked state
            if (isChecked) {
              htmlButton.style.setProperty('background', primaryColor);
              if (label) {
                (label as HTMLElement).style.setProperty('--color', '#ffffff');
                (label as HTMLElement).style.setProperty('color', '#ffffff');
              }
            } else {
              htmlButton.style.setProperty('background', 'transparent');
              if (label) {
                (label as HTMLElement).style.setProperty('--color', textColor);
                (label as HTMLElement).style.setProperty('color', textColor);
              }
            }
          } else {
            htmlButton.style.setProperty('--indicator-color', primaryColor);
            htmlButton.style.setProperty('--color-checked', primaryColor);
            htmlButton.style.setProperty('--ripple-color', primaryColor);
            
            // Reset text color for iOS as well
            if (label) {
              if (isChecked) {
                (label as HTMLElement).style.setProperty('--color', primaryColor);
                (label as HTMLElement).style.setProperty('color', primaryColor);
              } else {
                (label as HTMLElement).style.setProperty('--color', textColor);
                (label as HTMLElement).style.setProperty('color', textColor);
              }
            }
          }
        });
      }
    }
  }

  private initializeMonths() {
    // Generate months list (all 12 months)
    this.months = [
      { value: 'all', label: 'All Months' },
      { value: '0', label: 'January' },
      { value: '1', label: 'February' },
      { value: '2', label: 'March' },
      { value: '3', label: 'April' },
      { value: '4', label: 'May' },
      { value: '5', label: 'June' },
      { value: '6', label: 'July' },
      { value: '7', label: 'August' },
      { value: '8', label: 'September' },
      { value: '9', label: 'October' },
      { value: '10', label: 'November' },
      { value: '11', label: 'December' }
    ];
  }

  private initializeYears() {
    const now = new Date();
    const currentYear = now.getFullYear();
    
    // Generate years list (current year + 5 previous years)
    this.years = [
      { value: 'all', label: 'All Years' }
    ];

    for (let i = 0; i < 6; i++) {
      const year = currentYear - i;
      this.years.push({
        value: year.toString(),
        label: year.toString()
      });
    }
  }

  loadBookings() {
    this.bookingsService.getBookings().subscribe(bookings => {
      this.allBookings = bookings;
      this.filterBookings();
    });
  }

  segmentChanged(event: CustomEvent) {
    this.selectedSegment.set(event.detail.value);
    this.filterBookings();
    // Update segment colors after change
    setTimeout(() => {
      this.updateSegmentColor();
    }, 50);
  }

  monthChanged(event: CustomEvent) {
    const value = event.detail.value;
    this.selectedMonth.set(value);
    this.showAll.set(value === 'all' && this.selectedYear() === 'all');
    this.filterBookings();
  }

  yearChanged(event: CustomEvent) {
    const value = event.detail.value;
    this.selectedYear.set(value);
    this.showAll.set(value === 'all' && this.selectedMonth() === 'all');
    this.filterBookings();
  }

  filterBookings() {
    const status = this.selectedSegment();
    const monthFilter = this.selectedMonth();
    const yearFilter = this.selectedYear();
    
    // Filter by status
    let filtered = this.allBookings.filter(booking => booking.status === status);
    
    // Filter by year if not "all"
    if (yearFilter !== 'all') {
      const year = parseInt(yearFilter);
      filtered = filtered.filter(booking => {
        const bookingDate = new Date(booking.date);
        return bookingDate.getFullYear() === year;
      });
    }
    
    // Filter by month if not "all"
    if (monthFilter !== 'all') {
      const month = parseInt(monthFilter);
      filtered = filtered.filter(booking => {
        const bookingDate = new Date(booking.date);
        return bookingDate.getMonth() === month;
      });
    }
    
    this.filteredBookings.set(filtered);
    
    // Group by month if showing all
    if (this.showAll()) {
      this.groupByMonth(filtered);
    } else {
      this.monthGroups.set([]);
    }
  }

  private groupByMonth(bookings: Booking[]) {
    const groups = new Map<string, MonthGroup>();
    
    bookings.forEach(booking => {
      const bookingDate = new Date(booking.date);
      const year = bookingDate.getFullYear();
      const month = bookingDate.getMonth();
      const monthKey = `${year}-${String(month + 1).padStart(2, '0')}`;
      
      if (!groups.has(monthKey)) {
        const monthName = bookingDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
        groups.set(monthKey, {
          monthKey,
          monthName,
          year,
          bookings: []
        });
      }
      
      groups.get(monthKey)!.bookings.push(booking);
    });
    
    // Convert to array and sort by date (newest first)
    const sortedGroups = Array.from(groups.values()).sort((a, b) => {
      return b.monthKey.localeCompare(a.monthKey);
    });
    
    this.monthGroups.set(sortedGroups);
  }

  formatDate(date: Date): string {
    const d = new Date(date);
    return d.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  formatCurrency(amount: number): string {
    if (amount === 0) return 'N/A';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  }

  getSelectedMonthLabel(): string {
    const selected = this.selectedMonth();
    if (selected === 'all') {
      return 'Show All';
    }
    if (selected === 'current') {
      const now = new Date();
      return now.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    }
    // Find the month label from the months array
    const month = this.months.find(m => m.value === selected);
    return month ? month.label : 'Select Month';
  }

  getStatusColor(status: string): string {
    switch (status) {
      case 'upcoming':
        return 'primary';
      case 'completed':
        return 'success';
      case 'canceled':
        return 'danger';
      default:
        return 'medium';
    }
  }
}
