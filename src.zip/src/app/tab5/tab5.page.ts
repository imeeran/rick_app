import { Component, OnInit, OnDestroy, signal } from '@angular/core';
import { 
  IonContent,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonCardContent,
  IonItem,
  IonLabel,
  IonSegment,
  IonSegmentButton,
  IonIcon
} from '@ionic/angular/standalone';
import { ThemeService, Theme } from '../services/theme.service';
import { Subscription } from 'rxjs';
import { addIcons } from 'ionicons';
import { 
  documentText, 
  chevronForward,
  personOutline,
  briefcaseOutline,
  documentTextOutline,
  colorPaletteOutline,
  moonOutline,
  sunnyOutline
} from 'ionicons/icons';

interface Payslip {
  month: string;
  gross: string;
}

@Component({
  selector: 'app-tab5',
  templateUrl: 'tab5.page.html',
  styleUrls: ['tab5.page.scss'],
  imports: [
    IonContent,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardSubtitle,
    IonCardContent,
    IonItem,
    IonLabel,
    IonSegment,
    IonSegmentButton,
    IonIcon
  ],
})
export class Tab5Page implements OnInit, OnDestroy {
  selectedSegment = signal<string>('personal');
  themes: Theme[] = [];
  filteredThemes: Theme[] = [];
  currentTheme = signal<string>('default');
  themeMode = signal<'light' | 'dark'>('light');
  private themeSubscription?: Subscription;

  payslips: Payslip[] = [
    { month: 'December 2024', gross: '$5,000.00' },
    { month: 'November 2024', gross: '$5,000.00' },
    { month: 'October 2024', gross: '$5,000.00' },
    { month: 'September 2024', gross: '$5,000.00' }
  ];

  constructor(private themeService: ThemeService) {
    addIcons({ 
      documentText, 
      chevronForward,
      personOutline,
      briefcaseOutline,
      documentTextOutline,
      colorPaletteOutline,
      moonOutline,
      sunnyOutline
    });
  }

  ngOnInit(): void {
    this.themes = this.themeService.getThemes();
    this.currentTheme.set(this.themeService.getCurrentTheme());
    
    // Determine initial mode based on current theme
    const currentThemeObj = this.themes.find(t => t.name === this.currentTheme());
    if (currentThemeObj) {
      const isDark = this.themeService.isDarkColor(currentThemeObj.background);
      this.themeMode.set(isDark ? 'dark' : 'light');
    }
    
    this.filterThemes();
    
    this.themeSubscription = this.themeService.currentTheme$.subscribe(theme => {
      this.currentTheme.set(theme);
      // Update mode based on selected theme
      const themeObj = this.themes.find(t => t.name === theme);
      if (themeObj) {
        const isDark = this.themeService.isDarkColor(themeObj.background);
        this.themeMode.set(isDark ? 'dark' : 'light');
        this.filterThemes();
      }
    });
  }

  ngOnDestroy(): void {
    this.themeSubscription?.unsubscribe();
  }

  segmentChanged(event: CustomEvent): void {
    this.selectedSegment.set(event.detail.value);
  }

  selectTheme(themeName: string): void {
    this.themeService.setTheme(themeName);
    // Force update current theme signal to ensure UI reflects the change
    this.currentTheme.set(themeName);
  }

  onThemeModeChange(event: CustomEvent): void {
    const mode = event.detail.value as string;
    if (mode === 'light' || mode === 'dark') {
      this.themeMode.set(mode as 'light' | 'dark');
      this.filterThemes();
      
      // Automatically select default theme for the selected mode
      const defaultTheme = mode === 'dark' ? 'dark' : 'default';
      this.selectTheme(defaultTheme);
    }
  }

  private filterThemes(): void {
    this.filteredThemes = this.themeService.getThemesByMode(this.themeMode() === 'dark');
  }
}

