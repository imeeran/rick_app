import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

export interface Booking {
  id: string;
  date: Date;
  status: 'upcoming' | 'completed' | 'canceled';
  amount: number;
  pickupLocation: string;
  dropoffLocation: string;
  passengerName: string;
}

@Injectable({
  providedIn: 'root'
})
export class BookingsService {
  
  private mockBookings: Booking[] = this.generateMockBookings();

  constructor() {}

  getBookings(): Observable<Booking[]> {
    return of(this.mockBookings);
  }

  getBookingsByStatus(status: 'upcoming' | 'completed' | 'canceled'): Observable<Booking[]> {
    const filtered = this.mockBookings.filter(booking => booking.status === status);
    return of(filtered);
  }

  private generateMockBookings(): Booking[] {
    const bookings: Booking[] = [];
    const now = new Date();
    
    const locations = [
      { pickup: 'Downtown Station', dropoff: 'Airport Terminal' },
      { pickup: 'City Center', dropoff: 'Shopping Mall' },
      { pickup: 'University Campus', dropoff: 'Train Station' },
      { pickup: 'Hospital', dropoff: 'Residential Area' },
      { pickup: 'Hotel District', dropoff: 'Beach Front' },
      { pickup: 'Business Park', dropoff: 'Restaurant District' },
    ];

    const names = [
      'John Smith', 'Sarah Johnson', 'Michael Brown', 'Emily Davis',
      'David Wilson', 'Jessica Martinez', 'Robert Taylor', 'Amanda Anderson'
    ];

    // Generate upcoming bookings (future dates)
    for (let i = 0; i < 15; i++) {
      const daysAhead = Math.floor(Math.random() * 30) + 1;
      const date = new Date(now);
      date.setDate(date.getDate() + daysAhead);
      date.setHours(Math.floor(Math.random() * 24));
      date.setMinutes(Math.floor(Math.random() * 60));

      const location = locations[Math.floor(Math.random() * locations.length)];
      const amount = Math.floor(Math.random() * 50) + 10;

      bookings.push({
        id: `booking-upcoming-${i}`,
        date,
        status: 'upcoming',
        amount,
        pickupLocation: location.pickup,
        dropoffLocation: location.dropoff,
        passengerName: names[Math.floor(Math.random() * names.length)]
      });
    }

    // Generate completed bookings (past dates, various months)
    for (let i = 0; i < 60; i++) {
      const monthsAgo = Math.floor(Math.random() * 6); // Last 6 months
      const daysAgo = Math.floor(Math.random() * 30);
      const date = new Date(now);
      date.setMonth(date.getMonth() - monthsAgo);
      date.setDate(date.getDate() - daysAgo);
      date.setHours(Math.floor(Math.random() * 24));
      date.setMinutes(Math.floor(Math.random() * 60));

      const location = locations[Math.floor(Math.random() * locations.length)];
      const amount = Math.floor(Math.random() * 50) + 10;

      bookings.push({
        id: `booking-completed-${i}`,
        date,
        status: 'completed',
        amount,
        pickupLocation: location.pickup,
        dropoffLocation: location.dropoff,
        passengerName: names[Math.floor(Math.random() * names.length)]
      });
    }

    // Generate canceled bookings (past dates, various months)
    for (let i = 0; i < 25; i++) {
      const monthsAgo = Math.floor(Math.random() * 4); // Last 4 months
      const daysAgo = Math.floor(Math.random() * 30);
      const date = new Date(now);
      date.setMonth(date.getMonth() - monthsAgo);
      date.setDate(date.getDate() - daysAgo);
      date.setHours(Math.floor(Math.random() * 24));
      date.setMinutes(Math.floor(Math.random() * 60));

      const location = locations[Math.floor(Math.random() * locations.length)];

      bookings.push({
        id: `booking-canceled-${i}`,
        date,
        status: 'canceled',
        amount: 0,
        pickupLocation: location.pickup,
        dropoffLocation: location.dropoff,
        passengerName: names[Math.floor(Math.random() * names.length)]
      });
    }

    return bookings.sort((a, b) => {
      // Sort upcoming by date ascending, others by date descending
      if (a.status === 'upcoming' && b.status === 'upcoming') {
        return a.date.getTime() - b.date.getTime();
      }
      return b.date.getTime() - a.date.getTime();
    });
  }
}
