import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

export interface Ride {
  id: string;
  date: Date;
  status: 'completed' | 'canceled';
  amount: number;
}

export interface DashboardData {
  currentMonthCompletedRides: number;
  currentMonthCanceledRides: number;
  currentMonthEarnings: number;
  todayEarnings: number;
  ridesData: Ride[];
}

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  
  // Mock data - replace with actual API calls
  private mockRides: Ride[] = this.generateMockRides();

  constructor() {}

  getDashboardData(): Observable<DashboardData> {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    // Filter rides for current month
    const currentMonthRides = this.mockRides.filter(ride => {
      const rideDate = new Date(ride.date);
      return rideDate.getMonth() === currentMonth && 
             rideDate.getFullYear() === currentYear;
    });

    // Filter rides for today
    const todayRides = this.mockRides.filter(ride => {
      const rideDate = new Date(ride.date);
      return rideDate >= today && rideDate < new Date(today.getTime() + 24 * 60 * 60 * 1000);
    });

    const completedRides = currentMonthRides.filter(r => r.status === 'completed');
    const canceledRides = currentMonthRides.filter(r => r.status === 'canceled');

    const currentMonthEarnings = completedRides.reduce((sum, ride) => sum + ride.amount, 0);
    const todayEarnings = todayRides
      .filter(r => r.status === 'completed')
      .reduce((sum, ride) => sum + ride.amount, 0);

    return of({
      currentMonthCompletedRides: completedRides.length,
      currentMonthCanceledRides: canceledRides.length,
      currentMonthEarnings,
      todayEarnings,
      ridesData: currentMonthRides
    });
  }

  private generateMockRides(): Ride[] {
    const rides: Ride[] = [];
    const now = new Date();
    
    // Generate rides for the current month
    for (let i = 0; i < 45; i++) {
      const daysAgo = Math.floor(Math.random() * 30);
      const date = new Date(now);
      date.setDate(date.getDate() - daysAgo);
      date.setHours(Math.floor(Math.random() * 24));
      date.setMinutes(Math.floor(Math.random() * 60));

      const status: 'completed' | 'canceled' = Math.random() > 0.2 ? 'completed' : 'canceled';
      const amount = status === 'completed' ? Math.floor(Math.random() * 50) + 10 : 0;

      rides.push({
        id: `ride-${i}`,
        date,
        status,
        amount
      });
    }

    // Generate some rides for today
    for (let i = 0; i < 5; i++) {
      const hoursAgo = Math.floor(Math.random() * 24);
      const date = new Date(now);
      date.setHours(date.getHours() - hoursAgo);
      date.setMinutes(Math.floor(Math.random() * 60));

      const status: 'completed' | 'canceled' = Math.random() > 0.3 ? 'completed' : 'canceled';
      const amount = status === 'completed' ? Math.floor(Math.random() * 50) + 10 : 0;

      rides.push({
        id: `ride-today-${i}`,
        date,
        status,
        amount
      });
    }

    return rides.sort((a, b) => b.date.getTime() - a.date.getTime());
  }
}
